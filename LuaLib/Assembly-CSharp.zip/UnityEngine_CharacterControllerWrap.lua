---@class UnityEngine_CharacterControllerWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_CharacterControllerWrap = m
return m
