---@class TestClassA : System.Object
local m = {}

function m:Start() end

TestClassA = m
return m
