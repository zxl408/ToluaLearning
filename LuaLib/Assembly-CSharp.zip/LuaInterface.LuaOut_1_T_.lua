---@class LuaInterface.LuaOut_1_T_ : System.Object
local m = {}

LuaInterface.LuaOut_1_T_ = m
return m
