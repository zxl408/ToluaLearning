---@class GameModle : System.Object
local m = {}

GameModle = m
return m
