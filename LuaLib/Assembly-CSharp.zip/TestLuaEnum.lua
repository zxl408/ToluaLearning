---@class TestLuaEnum : System.Enum
---@field public One TestLuaEnum @static
---@field public Two TestLuaEnum @static
---@field public Three TestLuaEnum @static
---@field public Four TestLuaEnum @static
---@field public value__ number
local m = {}

TestLuaEnum = m
return m
