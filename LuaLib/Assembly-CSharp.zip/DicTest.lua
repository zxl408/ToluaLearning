---@class DicTest : UnityEngine.MonoBehaviour
---@field public asset UnityEngine.TextAsset
local m = {}

DicTest = m
return m
