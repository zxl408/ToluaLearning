---@class DicTest : UnityEngine.MonoBehaviour
local m = {}

DicTest = m
return m
