---@class System_EnumWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

System_EnumWrap = m
return m
