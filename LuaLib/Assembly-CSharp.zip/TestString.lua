---@class TestString : LuaClient
local m = {}

TestString = m
return m
