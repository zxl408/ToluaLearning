---@class TestAccount : System.Object
---@field public id number
---@field public name string
---@field public sex number
local m = {}

TestAccount = m
return m
