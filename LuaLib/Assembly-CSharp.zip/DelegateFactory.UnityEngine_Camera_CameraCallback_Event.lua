---@class DelegateFactory.UnityEngine_Camera_CameraCallback_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 UnityEngine.Camera
function m:Call(param0) end

---@param param0 UnityEngine.Camera
function m:CallWithSelf(param0) end

DelegateFactory.UnityEngine_Camera_CameraCallback_Event = m
return m
