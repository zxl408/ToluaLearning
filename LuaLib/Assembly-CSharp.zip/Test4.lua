---@class Test4 : UnityEngine.MonoBehaviour
local m = {}

Test4 = m
return m
