---@class Test3 : UnityEngine.MonoBehaviour
local m = {}

---@param arg1 number
---@return number
function m:Call(arg1) end

Test3 = m
return m
