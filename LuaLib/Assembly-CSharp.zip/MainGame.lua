---@class MainGame : UnityEngine.MonoBehaviour
---@field public luaGo UnityEngine.GameObject
local m = {}

MainGame = m
return m
