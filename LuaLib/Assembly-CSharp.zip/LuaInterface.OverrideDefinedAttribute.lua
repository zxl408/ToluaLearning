---@class LuaInterface.OverrideDefinedAttribute : System.Attribute
local m = {}

LuaInterface.OverrideDefinedAttribute = m
return m
