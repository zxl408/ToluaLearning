---@class DG_Tweening_PathModeWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

DG_Tweening_PathModeWrap = m
return m
