---@class LuaInterface.EventOp : System.Enum
---@field public None LuaInterface.EventOp @static
---@field public Add LuaInterface.EventOp @static
---@field public Sub LuaInterface.EventOp @static
---@field public value__ number
local m = {}

LuaInterface.EventOp = m
return m
