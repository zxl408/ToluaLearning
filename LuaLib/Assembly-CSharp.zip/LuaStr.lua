---@class LuaStr : LuaClient
---@field public luaFile string
local m = {}

LuaStr = m
return m
