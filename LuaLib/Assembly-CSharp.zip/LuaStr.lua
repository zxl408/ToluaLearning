---@class LuaStr : UnityEngine.MonoBehaviour
---@field public luaFile UnityEngine.TextAsset
local m = {}

LuaStr = m
return m
