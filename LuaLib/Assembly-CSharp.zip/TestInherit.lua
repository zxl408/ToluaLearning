---@class TestInherit : UnityEngine.MonoBehaviour
local m = {}

TestInherit = m
return m
