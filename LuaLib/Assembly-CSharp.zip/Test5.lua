---@class Test5 : UnityEngine.MonoBehaviour
---@field public luaFile UnityEngine.TextAsset
local m = {}

Test5 = m
return m
