---@class Test2 : UnityEngine.MonoBehaviour
---@field public rect1 UnityEngine.Rect
---@field public rect2 UnityEngine.Rect
---@field public filePath string
local m = {}

Test2 = m
return m
