---@class TestLuaThread : UnityEngine.MonoBehaviour
local m = {}

TestLuaThread = m
return m
