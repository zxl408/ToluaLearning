---@class Test8 : UnityEngine.MonoBehaviour
---@field public assetName string
local m = {}

Test8 = m
return m
