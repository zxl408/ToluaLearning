---@class Test8 : UnityEngine.MonoBehaviour
---@field public asset UnityEngine.TextAsset
local m = {}

Test8 = m
return m
