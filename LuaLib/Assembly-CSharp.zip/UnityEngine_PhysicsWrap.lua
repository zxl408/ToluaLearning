---@class UnityEngine_PhysicsWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_PhysicsWrap = m
return m
