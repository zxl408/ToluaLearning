---@class ClassLua : UnityEngine.MonoBehaviour
local m = {}

ClassLua = m
return m
