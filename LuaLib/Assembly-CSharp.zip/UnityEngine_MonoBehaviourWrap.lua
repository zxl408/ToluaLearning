---@class UnityEngine_MonoBehaviourWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_MonoBehaviourWrap = m
return m
