---@class DelegateFactory.DG_Tweening_Core_DOGetter_UnityEngine_RectOffset_Event : LuaInterface.LuaDelegate
local m = {}

---@return UnityEngine.RectOffset
function m:Call() end

---@return UnityEngine.RectOffset
function m:CallWithSelf() end

DelegateFactory.DG_Tweening_Core_DOGetter_UnityEngine_RectOffset_Event = m
return m
