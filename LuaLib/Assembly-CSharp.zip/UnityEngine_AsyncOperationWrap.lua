---@class UnityEngine_AsyncOperationWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_AsyncOperationWrap = m
return m
