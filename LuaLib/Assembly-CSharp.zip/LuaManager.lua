---@class LuaManager : LuaClient
---@field public LuaState LuaInterface.LuaState
local m = {}

LuaManager = m
return m
