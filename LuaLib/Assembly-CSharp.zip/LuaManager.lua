---@class LuaManager : UnityEngine.MonoBehaviour
---@field public Instance LuaManager @static
---@field public luaState LuaInterface.LuaState
---@field public looper LuaLooper
---@field public loder LuaResLoader
local m = {}

---@virtual
function m:OnLoadFileFinsh() end

LuaManager = m
return m
