---@class LuaCoroutine._CoWaitForSeconds_c__Iterator0 : System.Object
local m = {}

---@virtual
---@return boolean
function m:MoveNext() end

---@virtual
function m:Dispose() end

---@virtual
function m:Reset() end

LuaCoroutine._CoWaitForSeconds_c__Iterator0 = m
return m
