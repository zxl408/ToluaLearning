---@class UnityEngine_LightWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_LightWrap = m
return m
