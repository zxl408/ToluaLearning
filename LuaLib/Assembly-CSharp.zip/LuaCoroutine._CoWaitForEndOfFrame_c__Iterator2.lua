---@class LuaCoroutine._CoWaitForEndOfFrame_c__Iterator2 : System.Object
local m = {}

---@virtual
---@return boolean
function m:MoveNext() end

---@virtual
function m:Dispose() end

---@virtual
function m:Reset() end

LuaCoroutine._CoWaitForEndOfFrame_c__Iterator2 = m
return m
