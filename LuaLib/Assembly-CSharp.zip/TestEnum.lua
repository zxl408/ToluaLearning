---@class TestEnum : System.Object
local m = {}

---@param e UnityEngine.Space
function m:Test(e) end

TestEnum = m
return m
