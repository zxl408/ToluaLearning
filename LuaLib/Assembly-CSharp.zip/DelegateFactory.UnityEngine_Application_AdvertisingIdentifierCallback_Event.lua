---@class DelegateFactory.UnityEngine_Application_AdvertisingIdentifierCallback_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 string
---@param param1 boolean
---@param param2 string
function m:Call(param0, param1, param2) end

---@param param0 string
---@param param1 boolean
---@param param2 string
function m:CallWithSelf(param0, param1, param2) end

DelegateFactory.UnityEngine_Application_AdvertisingIdentifierCallback_Event = m
return m
