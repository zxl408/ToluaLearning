---@class TempCor : UnityEngine.MonoBehaviour
---@field public asset UnityEngine.TextAsset
local m = {}

TempCor = m
return m
