---@class LuaBaseBehaviourWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

LuaBaseBehaviourWrap = m
return m
