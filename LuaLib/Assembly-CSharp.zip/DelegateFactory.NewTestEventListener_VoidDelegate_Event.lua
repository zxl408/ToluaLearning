---@class DelegateFactory.NewTestEventListener_VoidDelegate_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 UnityEngine.GameObject
function m:Call(param0) end

---@param param0 UnityEngine.GameObject
function m:CallWithSelf(param0) end

DelegateFactory.NewTestEventListener_VoidDelegate_Event = m
return m
