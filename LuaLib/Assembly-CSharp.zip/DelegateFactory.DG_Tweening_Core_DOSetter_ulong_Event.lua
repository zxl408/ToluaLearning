---@class DelegateFactory.DG_Tweening_Core_DOSetter_ulong_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 number
function m:Call(param0) end

---@param param0 number
function m:CallWithSelf(param0) end

DelegateFactory.DG_Tweening_Core_DOSetter_ulong_Event = m
return m
