---@class LuaInterface.ToLuaFlags : System.Object
---@field public INDEX_ERROR number @static
---@field public USE_INT64 number @static
local m = {}

LuaInterface.ToLuaFlags = m
return m
