---@class LuaCoroutine._CoYield_c__Iterator3 : System.Object
local m = {}

---@virtual
---@return boolean
function m:MoveNext() end

---@virtual
function m:Dispose() end

---@virtual
function m:Reset() end

LuaCoroutine._CoYield_c__Iterator3 = m
return m
