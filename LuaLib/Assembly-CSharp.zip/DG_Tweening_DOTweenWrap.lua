---@class DG_Tweening_DOTweenWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

DG_Tweening_DOTweenWrap = m
return m
