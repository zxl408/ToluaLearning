---@class Test6 : LuaClient
---@field public asset UnityEngine.TextAsset
local m = {}

Test6 = m
return m
