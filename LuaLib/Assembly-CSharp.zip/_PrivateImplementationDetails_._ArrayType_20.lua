---@class _PrivateImplementationDetails_._ArrayType_20 : System.ValueType
local m = {}

_PrivateImplementationDetails_._ArrayType_20 = m
return m
