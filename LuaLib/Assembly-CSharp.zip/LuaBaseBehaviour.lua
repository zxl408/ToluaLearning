---@class LuaBaseBehaviour : UnityEngine.MonoBehaviour
---@field public luaClass LuaInterface.LuaTable
---@field public luaObj LuaInterface.LuaTable
---@field public className string
---@field public enableUpdateFunc boolean
---@field public isInit boolean
local m = {}

---@param className string
function m:Init(className) end

LuaBaseBehaviour = m
return m
