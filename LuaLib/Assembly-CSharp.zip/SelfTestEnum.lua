---@class SelfTestEnum : UnityEngine.MonoBehaviour
---@field public luaState LuaInterface.LuaState
---@field public fileName string
local m = {}

SelfTestEnum = m
return m
