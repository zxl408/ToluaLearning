---@class System_DelegateWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

System_DelegateWrap = m
return m
