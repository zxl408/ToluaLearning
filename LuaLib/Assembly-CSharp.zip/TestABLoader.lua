---@class TestABLoader : UnityEngine.MonoBehaviour
local m = {}

---@return System.Collections.IEnumerator
function m:LoadBundles() end

TestABLoader = m
return m
