---@class EventTest : UnityEngine.MonoBehaviour
local m = {}

EventTest = m
return m
