---@class Test : UnityEngine.MonoBehaviour
local m = {}

Test = m
return m
