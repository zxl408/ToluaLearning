---@class LuaCoroutine : System.Object
local m = {}

---@static
---@param state LuaInterface.LuaState
---@param behaviour UnityEngine.MonoBehaviour
function m.Register(state, behaviour) end

LuaCoroutine = m
return m
