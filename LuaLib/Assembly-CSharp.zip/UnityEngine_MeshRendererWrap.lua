---@class UnityEngine_MeshRendererWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_MeshRendererWrap = m
return m
