---@class UnityEngine_SleepTimeoutWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_SleepTimeoutWrap = m
return m
