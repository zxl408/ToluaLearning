---@class UseDictionary : UnityEngine.MonoBehaviour
local m = {}

UseDictionary = m
return m
