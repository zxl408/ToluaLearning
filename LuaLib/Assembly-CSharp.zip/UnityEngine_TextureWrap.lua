---@class UnityEngine_TextureWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_TextureWrap = m
return m
