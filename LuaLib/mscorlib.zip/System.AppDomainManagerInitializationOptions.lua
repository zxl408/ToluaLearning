---@class System.AppDomainManagerInitializationOptions : System.Enum
---@field public None System.AppDomainManagerInitializationOptions @static
---@field public RegisterWithHost System.AppDomainManagerInitializationOptions @static
---@field public value__ number
local m = {}

System.AppDomainManagerInitializationOptions = m
return m
