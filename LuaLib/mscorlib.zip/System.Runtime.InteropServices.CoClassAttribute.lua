---@class System.Runtime.InteropServices.CoClassAttribute : System.Attribute
---@field public CoClass System.Type
local m = {}

System.Runtime.InteropServices.CoClassAttribute = m
return m
