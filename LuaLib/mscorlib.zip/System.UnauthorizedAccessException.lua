---@class System.UnauthorizedAccessException : System.SystemException
local m = {}

System.UnauthorizedAccessException = m
return m
