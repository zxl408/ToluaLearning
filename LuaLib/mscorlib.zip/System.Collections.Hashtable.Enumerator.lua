---@class System.Collections.Hashtable.Enumerator : System.Object
---@field public Entry System.Collections.DictionaryEntry
---@field public Key any
---@field public Value any
---@field public Current any
local m = {}

---@virtual
function m:Reset() end

---@virtual
---@return boolean
function m:MoveNext() end

System.Collections.Hashtable.Enumerator = m
return m
