---@class System.Collections.SortedList.ListKeys : System.Object
---@field public Count number
---@field public IsSynchronized boolean
---@field public SyncRoot any
---@field public IsFixedSize boolean
---@field public IsReadOnly boolean
---@field public Item any
local m = {}

---@virtual
---@param array System.Array
---@param arrayIndex number
function m:CopyTo(array, arrayIndex) end

---@virtual
---@param value any
---@return number
function m:Add(value) end

---@virtual
function m:Clear() end

---@virtual
---@param key any
---@return boolean
function m:Contains(key) end

---@virtual
---@param key any
---@return number
function m:IndexOf(key) end

---@virtual
---@param index number
---@param value any
function m:Insert(index, value) end

---@virtual
---@param value any
function m:Remove(value) end

---@virtual
---@param index number
function m:RemoveAt(index) end

---@virtual
---@return System.Collections.IEnumerator
function m:GetEnumerator() end

System.Collections.SortedList.ListKeys = m
return m
