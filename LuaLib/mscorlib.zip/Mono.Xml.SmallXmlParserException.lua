---@class Mono.Xml.SmallXmlParserException : System.SystemException
---@field public Line number
---@field public Column number
local m = {}

Mono.Xml.SmallXmlParserException = m
return m
