---@class System.Collections.SortedList.Slot : System.ValueType
local m = {}

System.Collections.SortedList.Slot = m
return m
