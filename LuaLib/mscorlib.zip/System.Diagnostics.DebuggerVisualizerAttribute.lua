---@class System.Diagnostics.DebuggerVisualizerAttribute : System.Attribute
---@field public Description string
---@field public Target System.Type
---@field public TargetTypeName string
---@field public VisualizerObjectSourceTypeName string
---@field public VisualizerTypeName string
local m = {}

System.Diagnostics.DebuggerVisualizerAttribute = m
return m
