---@class System.MonoEnumInfo.LongComparer : System.Object
local m = {}

---@overload fun(ix:number, iy:number): @virtual
---@virtual
---@param x any
---@param y any
---@return number
function m:Compare(x, y) end

System.MonoEnumInfo.LongComparer = m
return m
