---@class System.Runtime.InteropServices.ComVisibleAttribute : System.Attribute
---@field public Value boolean
local m = {}

System.Runtime.InteropServices.ComVisibleAttribute = m
return m
