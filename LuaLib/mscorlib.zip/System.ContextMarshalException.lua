---@class System.ContextMarshalException : System.SystemException
local m = {}

System.ContextMarshalException = m
return m
