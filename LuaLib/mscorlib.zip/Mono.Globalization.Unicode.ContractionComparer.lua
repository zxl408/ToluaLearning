---@class Mono.Globalization.Unicode.ContractionComparer : System.Object
---@field public Instance Mono.Globalization.Unicode.ContractionComparer @static
local m = {}

---@virtual
---@param o1 any
---@param o2 any
---@return number
function m:Compare(o1, o2) end

Mono.Globalization.Unicode.ContractionComparer = m
return m
