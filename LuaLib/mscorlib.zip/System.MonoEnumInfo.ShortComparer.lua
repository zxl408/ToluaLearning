---@class System.MonoEnumInfo.ShortComparer : System.Object
local m = {}

---@overload fun(ix:number, iy:number): @virtual
---@virtual
---@param x any
---@param y any
---@return number
function m:Compare(x, y) end

System.MonoEnumInfo.ShortComparer = m
return m
