---@class System.Collections.Hashtable.SyncHashtable : System.Collections.Hashtable
---@field public Count number
---@field public IsSynchronized boolean
---@field public SyncRoot any
---@field public IsFixedSize boolean
---@field public IsReadOnly boolean
---@field public Keys System.Collections.ICollection
---@field public Values System.Collections.ICollection
---@field public Item any
local m = {}

---@virtual
---@param info System.Runtime.Serialization.SerializationInfo
---@param context System.Runtime.Serialization.StreamingContext
function m:GetObjectData(info, context) end

---@virtual
---@param array System.Array
---@param arrayIndex number
function m:CopyTo(array, arrayIndex) end

---@virtual
---@param key any
---@param value any
function m:Add(key, value) end

---@virtual
function m:Clear() end

---@virtual
---@param key any
---@return boolean
function m:Contains(key) end

---@virtual
---@return System.Collections.IDictionaryEnumerator
function m:GetEnumerator() end

---@virtual
---@param key any
function m:Remove(key) end

---@virtual
---@param key any
---@return boolean
function m:ContainsKey(key) end

---@virtual
---@param value any
---@return boolean
function m:ContainsValue(value) end

---@virtual
---@return any
function m:Clone() end

System.Collections.Hashtable.SyncHashtable = m
return m
