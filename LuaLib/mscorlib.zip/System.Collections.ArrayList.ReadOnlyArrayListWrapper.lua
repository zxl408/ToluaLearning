---@class System.Collections.ArrayList.ReadOnlyArrayListWrapper : System.Collections.ArrayList.FixedSizeArrayListWrapper
---@field public IsReadOnly boolean
---@field public Item any
local m = {}

---@overload fun(index:number, count:number) @virtual
---@virtual
function m:Reverse() end

---@virtual
---@param index number
---@param c System.Collections.ICollection
function m:SetRange(index, c) end

---@overload fun(comparer:System.Collections.IComparer) @virtual
---@overload fun(index:number, count:number, comparer:System.Collections.IComparer) @virtual
---@virtual
function m:Sort() end

System.Collections.ArrayList.ReadOnlyArrayListWrapper = m
return m
