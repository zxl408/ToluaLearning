---@class Mono.Math.BigInteger.Sign : System.Enum
---@field public Negative Mono.Math.BigInteger.Sign @static
---@field public Zero Mono.Math.BigInteger.Sign @static
---@field public Positive Mono.Math.BigInteger.Sign @static
---@field public value__ number
local m = {}

Mono.Math.BigInteger.Sign = m
return m
