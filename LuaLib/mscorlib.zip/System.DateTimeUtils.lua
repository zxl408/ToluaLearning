---@class System.DateTimeUtils : System.Object
local m = {}

---@static
---@param fmt string
---@param p number
---@param c number
---@return number
function m.CountRepeat(fmt, p, c) end

---@static
---@param output System.Text.StringBuilder
---@param digits number
---@param len number
function m.ZeroPad(output, digits, len) end

---@static
---@param fmt string
---@param pos number
---@param output System.Text.StringBuilder
---@return number
function m.ParseQuotedString(fmt, pos, output) end

---@overload fun(format:number, dfi:System.Globalization.DateTimeFormatInfo, date_time_offset:boolean):(, System.Boolean, System.Boolean) @static
---@static
---@param format number
---@param dfi System.Globalization.DateTimeFormatInfo
---@return string, System.Boolean, System.Boolean
function m.GetStandardPattern(format, dfi) end

---@overload fun(dt:System.DateTime, utc_offset:System.Nullable_1_System_TimeSpan_, format:string, dfi:System.Globalization.DateTimeFormatInfo): @static
---@static
---@param dt System.DateTime
---@param format string
---@param dfi System.Globalization.DateTimeFormatInfo
---@return string
function m.ToString(dt, format, dfi) end

System.DateTimeUtils = m
return m
