---@class System.Runtime.CompilerServices.CompilerGeneratedAttribute : System.Attribute
local m = {}

System.Runtime.CompilerServices.CompilerGeneratedAttribute = m
return m
