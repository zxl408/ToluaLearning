---@class System.CharInfo : System.ValueType
---@field public Character number
---@field public Attributes number
local m = {}

System.CharInfo = m
return m
