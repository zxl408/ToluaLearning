---@class Microsoft.Win32.SafeHandles.CriticalHandleMinusOneIsInvalid : System.Runtime.InteropServices.CriticalHandle
---@field public IsInvalid boolean
local m = {}

Microsoft.Win32.SafeHandles.CriticalHandleMinusOneIsInvalid = m
return m
