---@class System.Reflection.MemberInfo : System.Object
---@field public DeclaringType System.Type
---@field public MemberType System.Reflection.MemberTypes
---@field public Name string
---@field public ReflectedType System.Type
---@field public Module System.Reflection.Module
---@field public MetadataToken number
local m = {}

---@abstract
---@param attributeType System.Type
---@param inherit boolean
---@return boolean
function m:IsDefined(attributeType, inherit) end

---@overload fun(attributeType:System.Type, inherit:boolean): @abstract
---@abstract
---@param inherit boolean
---@return any[]
function m:GetCustomAttributes(inherit) end

System.Reflection.MemberInfo = m
return m
