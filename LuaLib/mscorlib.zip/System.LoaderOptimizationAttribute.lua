---@class System.LoaderOptimizationAttribute : System.Attribute
---@field public Value System.LoaderOptimization
local m = {}

System.LoaderOptimizationAttribute = m
return m
