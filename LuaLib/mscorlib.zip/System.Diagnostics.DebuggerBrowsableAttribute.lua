---@class System.Diagnostics.DebuggerBrowsableAttribute : System.Attribute
---@field public State System.Diagnostics.DebuggerBrowsableState
local m = {}

System.Diagnostics.DebuggerBrowsableAttribute = m
return m
