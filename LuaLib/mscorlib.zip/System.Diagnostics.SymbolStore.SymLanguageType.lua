---@class System.Diagnostics.SymbolStore.SymLanguageType : System.Object
---@field public Basic System.Guid @static
---@field public C System.Guid @static
---@field public Cobol System.Guid @static
---@field public CPlusPlus System.Guid @static
---@field public CSharp System.Guid @static
---@field public ILAssembly System.Guid @static
---@field public Java System.Guid @static
---@field public JScript System.Guid @static
---@field public MCPlusPlus System.Guid @static
---@field public Pascal System.Guid @static
---@field public SMC System.Guid @static
local m = {}

System.Diagnostics.SymbolStore.SymLanguageType = m
return m
