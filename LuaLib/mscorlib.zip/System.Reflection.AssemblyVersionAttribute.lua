---@class System.Reflection.AssemblyVersionAttribute : System.Attribute
---@field public Version string
local m = {}

System.Reflection.AssemblyVersionAttribute = m
return m
