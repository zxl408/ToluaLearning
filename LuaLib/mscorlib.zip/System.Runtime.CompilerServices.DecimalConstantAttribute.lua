---@class System.Runtime.CompilerServices.DecimalConstantAttribute : System.Attribute
---@field public Value System.Decimal
local m = {}

System.Runtime.CompilerServices.DecimalConstantAttribute = m
return m
