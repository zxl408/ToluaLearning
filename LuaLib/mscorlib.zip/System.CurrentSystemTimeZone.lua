---@class System.CurrentSystemTimeZone : System.TimeZone
---@field public DaylightName string
---@field public StandardName string
local m = {}

---@virtual
---@param year number
---@return System.Globalization.DaylightTime
function m:GetDaylightChanges(year) end

---@virtual
---@param time System.DateTime
---@return System.TimeSpan
function m:GetUtcOffset(time) end

System.CurrentSystemTimeZone = m
return m
