---@class System.OrdinalComparer : System.StringComparer
local m = {}

---@virtual
---@param x string
---@param y string
---@return number
function m:Compare(x, y) end

---@virtual
---@param x string
---@param y string
---@return boolean
function m:Equals(x, y) end

---@virtual
---@param s string
---@return number
function m:GetHashCode(s) end

System.OrdinalComparer = m
return m
