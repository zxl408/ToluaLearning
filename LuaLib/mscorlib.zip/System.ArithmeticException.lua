---@class System.ArithmeticException : System.SystemException
local m = {}

System.ArithmeticException = m
return m
