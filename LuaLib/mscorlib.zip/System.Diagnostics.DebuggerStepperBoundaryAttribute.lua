---@class System.Diagnostics.DebuggerStepperBoundaryAttribute : System.Attribute
local m = {}

System.Diagnostics.DebuggerStepperBoundaryAttribute = m
return m
