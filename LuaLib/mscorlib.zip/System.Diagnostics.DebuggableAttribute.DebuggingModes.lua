---@class System.Diagnostics.DebuggableAttribute.DebuggingModes : System.Enum
---@field public None System.Diagnostics.DebuggableAttribute.DebuggingModes @static
---@field public Default System.Diagnostics.DebuggableAttribute.DebuggingModes @static
---@field public IgnoreSymbolStoreSequencePoints System.Diagnostics.DebuggableAttribute.DebuggingModes @static
---@field public EnableEditAndContinue System.Diagnostics.DebuggableAttribute.DebuggingModes @static
---@field public DisableOptimizations System.Diagnostics.DebuggableAttribute.DebuggingModes @static
---@field public value__ number
local m = {}

System.Diagnostics.DebuggableAttribute.DebuggingModes = m
return m
