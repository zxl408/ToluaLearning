---@class Mono.Globalization.Unicode.SimpleCollator.ExtenderType : System.Enum
---@field public None Mono.Globalization.Unicode.SimpleCollator.ExtenderType @static
---@field public Simple Mono.Globalization.Unicode.SimpleCollator.ExtenderType @static
---@field public Voiced Mono.Globalization.Unicode.SimpleCollator.ExtenderType @static
---@field public Conditional Mono.Globalization.Unicode.SimpleCollator.ExtenderType @static
---@field public Buggy Mono.Globalization.Unicode.SimpleCollator.ExtenderType @static
---@field public value__ number
local m = {}

Mono.Globalization.Unicode.SimpleCollator.ExtenderType = m
return m
