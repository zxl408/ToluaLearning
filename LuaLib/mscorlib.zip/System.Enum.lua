---@class System.Enum : System.ValueType
local m = {}

---@virtual
---@return System.TypeCode
function m:GetTypeCode() end

---@static
---@param enumType System.Type
---@return System.Array
function m.GetValues(enumType) end

---@static
---@param enumType System.Type
---@return string[]
function m.GetNames(enumType) end

---@static
---@param enumType System.Type
---@param value any
---@return string
function m.GetName(enumType, value) end

---@static
---@param enumType System.Type
---@param value any
---@return boolean
function m.IsDefined(enumType, value) end

---@static
---@param enumType System.Type
---@return System.Type
function m.GetUnderlyingType(enumType) end

---@overload fun(enumType:System.Type, value:string, ignoreCase:boolean): @static
---@static
---@param enumType System.Type
---@param value string
---@return any
function m.Parse(enumType, value) end

---@virtual
---@param target any
---@return number
function m:CompareTo(target) end

---@overload fun(provider:System.IFormatProvider): @virtual
---@overload fun(format:string):
---@overload fun(format:string, provider:System.IFormatProvider): @virtual
---@virtual
---@return string
function m:ToString() end

---@overload fun(enumType:System.Type, value:number): @static
---@overload fun(enumType:System.Type, value:number): @static
---@overload fun(enumType:System.Type, value:number): @static
---@overload fun(enumType:System.Type, value:any): @static
---@overload fun(enumType:System.Type, value:number): @static
---@overload fun(enumType:System.Type, value:number): @static
---@overload fun(enumType:System.Type, value:number): @static
---@overload fun(enumType:System.Type, value:number): @static
---@static
---@param enumType System.Type
---@param value number
---@return any
function m.ToObject(enumType, value) end

---@virtual
---@param obj any
---@return boolean
function m:Equals(obj) end

---@virtual
---@return number
function m:GetHashCode() end

---@static
---@param enumType System.Type
---@param value any
---@param format string
---@return string
function m.Format(enumType, value, format) end

System.Enum = m
return m
