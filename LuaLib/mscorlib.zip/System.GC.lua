---@class System.GC : System.Object
---@field public MaxGeneration number @static
local m = {}

---@overload fun(generation:number) @static
---@overload fun(generation:number, mode:System.GCCollectionMode) @static
---@static
function m.Collect() end

---@overload fun(wo:System.WeakReference): @static
---@static
---@param obj any
---@return number
function m.GetGeneration(obj) end

---@static
---@param forceFullCollection boolean
---@return number
function m.GetTotalMemory(forceFullCollection) end

---@static
---@param obj any
function m.KeepAlive(obj) end

---@static
---@param obj any
function m.ReRegisterForFinalize(obj) end

---@static
---@param obj any
function m.SuppressFinalize(obj) end

---@static
function m.WaitForPendingFinalizers() end

---@static
---@param generation number
---@return number
function m.CollectionCount(generation) end

---@static
---@param bytesAllocated number
function m.AddMemoryPressure(bytesAllocated) end

---@static
---@param bytesAllocated number
function m.RemoveMemoryPressure(bytesAllocated) end

System.GC = m
return m
