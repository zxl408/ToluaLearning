---@class Mono.Globalization.Unicode.Normalization : System.Object
---@field public NoNfd number @static
---@field public NoNfkd number @static
---@field public NoNfc number @static
---@field public MaybeNfc number @static
---@field public NoNfkc number @static
---@field public MaybeNfkc number @static
---@field public FullCompositionExclusion number @static
---@field public IsUnsafe number @static
---@field public isReady boolean @static
---@field public IsReady boolean @static
local m = {}

---@static
---@param c number
---@param type number
---@return Mono.Globalization.Unicode.NormalizationCheck
function m.QuickCheck(c, type) end

---@static
---@param c number
---@param buf number[]
---@param bufIdx number
function m.GetCanonical(c, buf, bufIdx) end

---@static
---@param source string
---@param type number
---@return boolean
function m.IsNormalized(source, type) end

---@static
---@param source string
---@param type number
---@return string
function m.Normalize(source, type) end

Mono.Globalization.Unicode.Normalization = m
return m
