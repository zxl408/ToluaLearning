---@class UnityEngine.ComputeBuffer : System.Object
---@field public count number
---@field public stride number
local m = {}

---@virtual
function m:Dispose() end

function m:Release() end

---@param data System.Array
function m:SetData(data) end

---@param counterValue number
function m:SetCounterValue(counterValue) end

---@param data System.Array
function m:GetData(data) end

---@static
---@param src UnityEngine.ComputeBuffer
---@param dst UnityEngine.ComputeBuffer
---@param dstOffset number
function m.CopyCount(src, dst, dstOffset) end

---@return System.IntPtr
function m:GetNativeBufferPtr() end

UnityEngine.ComputeBuffer = m
return m
