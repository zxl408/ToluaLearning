---@class UnityEngine.SamsungTV.GamePadMode : System.Enum
---@field public Default UnityEngine.SamsungTV.GamePadMode @static
---@field public Mouse UnityEngine.SamsungTV.GamePadMode @static
---@field public value__ number
local m = {}

UnityEngine.SamsungTV.GamePadMode = m
return m
