---@class UnityEngine.ParticleSystem.IteratorDelegate : System.MulticastDelegate
local m = {}

---@virtual
---@param ps UnityEngine.ParticleSystem
---@return boolean
function m:Invoke(ps) end

---@virtual
---@param ps UnityEngine.ParticleSystem
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(ps, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return boolean
function m:EndInvoke(result) end

UnityEngine.ParticleSystem.IteratorDelegate = m
return m
