---@class UnityEngine.NetworkDisconnection : System.Enum
---@field public LostConnection UnityEngine.NetworkDisconnection @static
---@field public Disconnected UnityEngine.NetworkDisconnection @static
---@field public value__ number
local m = {}

UnityEngine.NetworkDisconnection = m
return m
