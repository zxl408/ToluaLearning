---@class UnityEngine.Rendering.UVChannelFlags : System.Enum
---@field public UV0 UnityEngine.Rendering.UVChannelFlags @static
---@field public UV1 UnityEngine.Rendering.UVChannelFlags @static
---@field public UV2 UnityEngine.Rendering.UVChannelFlags @static
---@field public UV3 UnityEngine.Rendering.UVChannelFlags @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.UVChannelFlags = m
return m
