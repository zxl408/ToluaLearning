---@class UnityEngine.GeometryUtility : System.Object
local m = {}

---@static
---@param planes UnityEngine.Plane[]
---@param bounds UnityEngine.Bounds
---@return boolean
function m.TestPlanesAABB(planes, bounds) end

---@overload fun(worldToProjectionMatrix:UnityEngine.Matrix4x4): @static
---@static
---@param camera UnityEngine.Camera
---@return UnityEngine.Plane[]
function m.CalculateFrustumPlanes(camera) end

---@static
---@param positions UnityEngine.Vector3[]
---@param transform UnityEngine.Matrix4x4
---@return UnityEngine.Bounds
function m.CalculateBounds(positions, transform) end

UnityEngine.GeometryUtility = m
return m
