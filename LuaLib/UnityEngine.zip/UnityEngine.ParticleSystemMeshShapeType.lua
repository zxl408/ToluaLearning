---@class UnityEngine.ParticleSystemMeshShapeType : System.Enum
---@field public Vertex UnityEngine.ParticleSystemMeshShapeType @static
---@field public Edge UnityEngine.ParticleSystemMeshShapeType @static
---@field public Triangle UnityEngine.ParticleSystemMeshShapeType @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemMeshShapeType = m
return m
