---@class UnityEngine.WeakListenerBindings : System.Object
local m = {}

---@static
---@param inst any
---@param gchandle System.Runtime.InteropServices.GCHandle
---@param parameters any[]
function m.InvokeCallbacks(inst, gchandle, parameters) end

UnityEngine.WeakListenerBindings = m
return m
