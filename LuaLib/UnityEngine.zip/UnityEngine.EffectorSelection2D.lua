---@class UnityEngine.EffectorSelection2D : System.Enum
---@field public Rigidbody UnityEngine.EffectorSelection2D @static
---@field public Collider UnityEngine.EffectorSelection2D @static
---@field public value__ number
local m = {}

UnityEngine.EffectorSelection2D = m
return m
