---@class UnityEngine.SurfaceEffector2D : UnityEngine.Effector2D
---@field public speed number
---@field public speedVariation number
---@field public forceScale number
---@field public useContactForce boolean
---@field public useFriction boolean
---@field public useBounce boolean
local m = {}

UnityEngine.SurfaceEffector2D = m
return m
