---@class UnityEngine.ParticleSystem.LimitVelocityOverLifetimeModule : System.ValueType
---@field public enabled boolean
---@field public limitX UnityEngine.ParticleSystem.MinMaxCurve
---@field public limitXMultiplier number
---@field public limitY UnityEngine.ParticleSystem.MinMaxCurve
---@field public limitYMultiplier number
---@field public limitZ UnityEngine.ParticleSystem.MinMaxCurve
---@field public limitZMultiplier number
---@field public limit UnityEngine.ParticleSystem.MinMaxCurve
---@field public limitMultiplier number
---@field public dampen number
---@field public separateAxes boolean
---@field public space UnityEngine.ParticleSystemSimulationSpace
local m = {}

UnityEngine.ParticleSystem.LimitVelocityOverLifetimeModule = m
return m
