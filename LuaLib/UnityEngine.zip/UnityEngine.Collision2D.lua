---@class UnityEngine.Collision2D : System.Object
---@field public collider UnityEngine.Collider2D
---@field public otherCollider UnityEngine.Collider2D
---@field public rigidbody UnityEngine.Rigidbody2D
---@field public otherRigidbody UnityEngine.Rigidbody2D
---@field public transform UnityEngine.Transform
---@field public gameObject UnityEngine.GameObject
---@field public contacts UnityEngine.ContactPoint2D[]
---@field public relativeVelocity UnityEngine.Vector2
---@field public enabled boolean
local m = {}

UnityEngine.Collision2D = m
return m
