---@class UnityEngine.CompositeCollider2D : UnityEngine.Collider2D
---@field public geometryType UnityEngine.CompositeCollider2D.GeometryType
---@field public generationType UnityEngine.CompositeCollider2D.GenerationType
---@field public vertexDistance number
---@field public edgeRadius number
---@field public pathCount number
---@field public pointCount number
local m = {}

function m:GenerateGeometry() end

---@param index number
---@return number
function m:GetPathPointCount(index) end

---@param index number
---@param points UnityEngine.Vector2[]
---@return number
function m:GetPath(index, points) end

UnityEngine.CompositeCollider2D = m
return m
