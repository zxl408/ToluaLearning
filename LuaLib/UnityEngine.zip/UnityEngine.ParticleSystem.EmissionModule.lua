---@class UnityEngine.ParticleSystem.EmissionModule : System.ValueType
---@field public enabled boolean
---@field public rateOverTime UnityEngine.ParticleSystem.MinMaxCurve
---@field public rateOverTimeMultiplier number
---@field public rateOverDistance UnityEngine.ParticleSystem.MinMaxCurve
---@field public rateOverDistanceMultiplier number
---@field public burstCount number
---@field public type UnityEngine.ParticleSystemEmissionType
---@field public rate UnityEngine.ParticleSystem.MinMaxCurve
---@field public rateMultiplier number
local m = {}

---@overload fun(bursts:UnityEngine.ParticleSystem.Burst[], size:number)
---@param bursts UnityEngine.ParticleSystem.Burst[]
function m:SetBursts(bursts) end

---@param bursts UnityEngine.ParticleSystem.Burst[]
---@return number
function m:GetBursts(bursts) end

UnityEngine.ParticleSystem.EmissionModule = m
return m
