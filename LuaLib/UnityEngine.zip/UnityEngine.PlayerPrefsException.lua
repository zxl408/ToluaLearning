---@class UnityEngine.PlayerPrefsException : System.Exception
local m = {}

UnityEngine.PlayerPrefsException = m
return m
