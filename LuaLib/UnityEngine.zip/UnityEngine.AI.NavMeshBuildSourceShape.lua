---@class UnityEngine.AI.NavMeshBuildSourceShape : System.Enum
---@field public Mesh UnityEngine.AI.NavMeshBuildSourceShape @static
---@field public Terrain UnityEngine.AI.NavMeshBuildSourceShape @static
---@field public Box UnityEngine.AI.NavMeshBuildSourceShape @static
---@field public Sphere UnityEngine.AI.NavMeshBuildSourceShape @static
---@field public Capsule UnityEngine.AI.NavMeshBuildSourceShape @static
---@field public ModifierBox UnityEngine.AI.NavMeshBuildSourceShape @static
---@field public value__ number
local m = {}

UnityEngine.AI.NavMeshBuildSourceShape = m
return m
