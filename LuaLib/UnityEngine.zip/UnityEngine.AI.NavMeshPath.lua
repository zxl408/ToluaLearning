---@class UnityEngine.AI.NavMeshPath : System.Object
---@field public corners UnityEngine.Vector3[]
---@field public status UnityEngine.AI.NavMeshPathStatus
local m = {}

---@param results UnityEngine.Vector3[]
---@return number
function m:GetCornersNonAlloc(results) end

function m:ClearCorners() end

UnityEngine.AI.NavMeshPath = m
return m
