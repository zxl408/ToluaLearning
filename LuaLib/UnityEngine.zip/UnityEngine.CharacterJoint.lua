---@class UnityEngine.CharacterJoint : UnityEngine.Joint
---@field public targetRotation UnityEngine.Quaternion
---@field public targetAngularVelocity UnityEngine.Vector3
---@field public rotationDrive UnityEngine.JointDrive
---@field public swingAxis UnityEngine.Vector3
---@field public twistLimitSpring UnityEngine.SoftJointLimitSpring
---@field public swingLimitSpring UnityEngine.SoftJointLimitSpring
---@field public lowTwistLimit UnityEngine.SoftJointLimit
---@field public highTwistLimit UnityEngine.SoftJointLimit
---@field public swing1Limit UnityEngine.SoftJointLimit
---@field public swing2Limit UnityEngine.SoftJointLimit
---@field public enableProjection boolean
---@field public projectionDistance number
---@field public projectionAngle number
local m = {}

UnityEngine.CharacterJoint = m
return m
