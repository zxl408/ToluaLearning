---@class UnityEngine.Projector : UnityEngine.Behaviour
---@field public nearClipPlane number
---@field public farClipPlane number
---@field public fieldOfView number
---@field public aspectRatio number
---@field public orthographic boolean
---@field public orthographicSize number
---@field public ignoreLayers number
---@field public material UnityEngine.Material
---@field public isOrthoGraphic boolean
---@field public orthoGraphicSize number
local m = {}

UnityEngine.Projector = m
return m
