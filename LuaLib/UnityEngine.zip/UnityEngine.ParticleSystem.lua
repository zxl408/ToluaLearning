---@class UnityEngine.ParticleSystem : UnityEngine.Component
---@field public safeCollisionEventSize number
---@field public startDelay number
---@field public isPlaying boolean
---@field public isEmitting boolean
---@field public isStopped boolean
---@field public isPaused boolean
---@field public loop boolean
---@field public playOnAwake boolean
---@field public time number
---@field public duration number
---@field public playbackSpeed number
---@field public particleCount number
---@field public enableEmission boolean
---@field public emissionRate number
---@field public startSpeed number
---@field public startSize number
---@field public startColor UnityEngine.Color
---@field public startRotation number
---@field public startRotation3D UnityEngine.Vector3
---@field public startLifetime number
---@field public gravityModifier number
---@field public maxParticles number
---@field public simulationSpace UnityEngine.ParticleSystemSimulationSpace
---@field public scalingMode UnityEngine.ParticleSystemScalingMode
---@field public randomSeed number
---@field public useAutoRandomSeed boolean
---@field public main UnityEngine.ParticleSystem.MainModule
---@field public emission UnityEngine.ParticleSystem.EmissionModule
---@field public shape UnityEngine.ParticleSystem.ShapeModule
---@field public velocityOverLifetime UnityEngine.ParticleSystem.VelocityOverLifetimeModule
---@field public limitVelocityOverLifetime UnityEngine.ParticleSystem.LimitVelocityOverLifetimeModule
---@field public inheritVelocity UnityEngine.ParticleSystem.InheritVelocityModule
---@field public forceOverLifetime UnityEngine.ParticleSystem.ForceOverLifetimeModule
---@field public colorOverLifetime UnityEngine.ParticleSystem.ColorOverLifetimeModule
---@field public colorBySpeed UnityEngine.ParticleSystem.ColorBySpeedModule
---@field public sizeOverLifetime UnityEngine.ParticleSystem.SizeOverLifetimeModule
---@field public sizeBySpeed UnityEngine.ParticleSystem.SizeBySpeedModule
---@field public rotationOverLifetime UnityEngine.ParticleSystem.RotationOverLifetimeModule
---@field public rotationBySpeed UnityEngine.ParticleSystem.RotationBySpeedModule
---@field public externalForces UnityEngine.ParticleSystem.ExternalForcesModule
---@field public noise UnityEngine.ParticleSystem.NoiseModule
---@field public collision UnityEngine.ParticleSystem.CollisionModule
---@field public trigger UnityEngine.ParticleSystem.TriggerModule
---@field public subEmitters UnityEngine.ParticleSystem.SubEmittersModule
---@field public textureSheetAnimation UnityEngine.ParticleSystem.TextureSheetAnimationModule
---@field public lights UnityEngine.ParticleSystem.LightsModule
---@field public trails UnityEngine.ParticleSystem.TrailModule
---@field public customData UnityEngine.ParticleSystem.CustomDataModule
local m = {}

---@param particles UnityEngine.ParticleSystem.Particle[]
---@param size number
function m:SetParticles(particles, size) end

---@param particles UnityEngine.ParticleSystem.Particle[]
---@return number
function m:GetParticles(particles) end

---@param customData UnityEngine.Vector4[]
---@param streamIndex UnityEngine.ParticleSystemCustomData
function m:SetCustomParticleData(customData, streamIndex) end

---@param customData UnityEngine.Vector4[]
---@param streamIndex UnityEngine.ParticleSystemCustomData
---@return number
function m:GetCustomParticleData(customData, streamIndex) end

---@overload fun(t:number, withChildren:boolean)
---@overload fun(t:number)
---@overload fun(t:number, withChildren:boolean, restart:boolean, fixedTimeStep:boolean)
---@param t number
---@param withChildren boolean
---@param restart boolean
function m:Simulate(t, withChildren, restart) end

---@overload fun(withChildren:boolean)
function m:Play() end

---@overload fun()
---@overload fun(withChildren:boolean, stopBehavior:UnityEngine.ParticleSystemStopBehavior)
---@param withChildren boolean
function m:Stop(withChildren) end

---@overload fun(withChildren:boolean)
function m:Pause() end

---@overload fun(withChildren:boolean)
function m:Clear() end

---@overload fun(withChildren:boolean):
---@return boolean
function m:IsAlive() end

---@overload fun(position:UnityEngine.Vector3, velocity:UnityEngine.Vector3, size:number, lifetime:number, color:UnityEngine.Color32)
---@overload fun(particle:UnityEngine.ParticleSystem.Particle)
---@overload fun(emitParams:UnityEngine.ParticleSystem.EmitParams, count:number)
---@param count number
function m:Emit(count) end

---@extension
---@return number
function m.GetSafeCollisionEventSize() end

---@overload fun(go:UnityEngine.GameObject, collisionEvents:UnityEngine.ParticleCollisionEvent[]): @extension
---@extension
---@param go UnityEngine.GameObject
---@param collisionEvents UnityEngine.ParticleCollisionEvent[]
---@return number
function m.GetCollisionEvents(go, collisionEvents) end

---@extension
---@param type UnityEngine.ParticleSystemTriggerEventType
---@return number
function m.GetSafeTriggerParticlesSize(type) end

---@extension
---@param type UnityEngine.ParticleSystemTriggerEventType
---@param particles UnityEngine.ParticleSystem.Particle[]
---@return number
function m.GetTriggerParticles(type, particles) end

---@overload fun(type:UnityEngine.ParticleSystemTriggerEventType, particles:UnityEngine.ParticleSystem.Particle[]) @extension
---@extension
---@param type UnityEngine.ParticleSystemTriggerEventType
---@param particles UnityEngine.ParticleSystem.Particle[]
---@param offset number
---@param count number
function m.SetTriggerParticles(type, particles, offset, count) end

UnityEngine.ParticleSystem = m
return m
