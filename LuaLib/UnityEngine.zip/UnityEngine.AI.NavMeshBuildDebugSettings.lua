---@class UnityEngine.AI.NavMeshBuildDebugSettings : System.ValueType
---@field public showInputGeom boolean
---@field public showVoxels boolean
---@field public showRegions boolean
---@field public showRawContours boolean
---@field public showContours boolean
---@field public showPolyMesh boolean
---@field public showPolyMeshDetail boolean
---@field public useFocus boolean
---@field public focusPoint UnityEngine.Vector3
local m = {}

UnityEngine.AI.NavMeshBuildDebugSettings = m
return m
