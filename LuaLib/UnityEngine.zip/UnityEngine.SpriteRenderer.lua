---@class UnityEngine.SpriteRenderer : UnityEngine.Renderer
---@field public sprite UnityEngine.Sprite
---@field public drawMode UnityEngine.SpriteDrawMode
---@field public size UnityEngine.Vector2
---@field public adaptiveModeThreshold number
---@field public tileMode UnityEngine.SpriteTileMode
---@field public color UnityEngine.Color
---@field public flipX boolean
---@field public flipY boolean
local m = {}

UnityEngine.SpriteRenderer = m
return m
