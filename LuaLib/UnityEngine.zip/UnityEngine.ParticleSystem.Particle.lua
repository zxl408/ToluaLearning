---@class UnityEngine.ParticleSystem.Particle : System.ValueType
---@field public position UnityEngine.Vector3
---@field public velocity UnityEngine.Vector3
---@field public lifetime number
---@field public remainingLifetime number
---@field public startLifetime number
---@field public startSize number
---@field public startSize3D UnityEngine.Vector3
---@field public axisOfRotation UnityEngine.Vector3
---@field public rotation number
---@field public rotation3D UnityEngine.Vector3
---@field public angularVelocity number
---@field public angularVelocity3D UnityEngine.Vector3
---@field public startColor UnityEngine.Color32
---@field public randomValue number
---@field public randomSeed number
---@field public size number
---@field public color UnityEngine.Color32
local m = {}

---@param system UnityEngine.ParticleSystem
---@return number
function m:GetCurrentSize(system) end

---@param system UnityEngine.ParticleSystem
---@return UnityEngine.Vector3
function m:GetCurrentSize3D(system) end

---@param system UnityEngine.ParticleSystem
---@return UnityEngine.Color32
function m:GetCurrentColor(system) end

UnityEngine.ParticleSystem.Particle = m
return m
