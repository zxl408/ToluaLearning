---@class UnityEngine.AI.NavMeshTriangulation : System.ValueType
---@field public vertices UnityEngine.Vector3[]
---@field public indices number[]
---@field public areas number[]
---@field public layers number[]
local m = {}

UnityEngine.AI.NavMeshTriangulation = m
return m
