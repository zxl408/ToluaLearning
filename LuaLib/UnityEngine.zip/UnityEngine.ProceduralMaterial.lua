---@class UnityEngine.ProceduralMaterial : UnityEngine.Material
---@field public isSupported boolean @static
---@field public substanceProcessorUsage UnityEngine.ProceduralProcessorUsage @static
---@field public cacheSize UnityEngine.ProceduralCacheSize
---@field public animationUpdateRate number
---@field public isProcessing boolean
---@field public isCachedDataAvailable boolean
---@field public isLoadTimeGenerated boolean
---@field public loadingBehavior UnityEngine.ProceduralLoadingBehavior
---@field public preset string
---@field public isReadable boolean
---@field public isFrozen boolean
local m = {}

---@return UnityEngine.ProceduralPropertyDescription[]
function m:GetProceduralPropertyDescriptions() end

---@param inputName string
---@return boolean
function m:HasProceduralProperty(inputName) end

---@param inputName string
---@return boolean
function m:GetProceduralBoolean(inputName) end

---@param inputName string
---@return boolean
function m:IsProceduralPropertyVisible(inputName) end

---@param inputName string
---@param value boolean
function m:SetProceduralBoolean(inputName, value) end

---@param inputName string
---@return number
function m:GetProceduralFloat(inputName) end

---@param inputName string
---@param value number
function m:SetProceduralFloat(inputName, value) end

---@param inputName string
---@return UnityEngine.Vector4
function m:GetProceduralVector(inputName) end

---@param inputName string
---@param value UnityEngine.Vector4
function m:SetProceduralVector(inputName, value) end

---@param inputName string
---@return UnityEngine.Color
function m:GetProceduralColor(inputName) end

---@param inputName string
---@param value UnityEngine.Color
function m:SetProceduralColor(inputName, value) end

---@param inputName string
---@return number
function m:GetProceduralEnum(inputName) end

---@param inputName string
---@param value number
function m:SetProceduralEnum(inputName, value) end

---@param inputName string
---@return UnityEngine.Texture2D
function m:GetProceduralTexture(inputName) end

---@param inputName string
---@param value UnityEngine.Texture2D
function m:SetProceduralTexture(inputName, value) end

---@param inputName string
---@return boolean
function m:IsProceduralPropertyCached(inputName) end

---@param inputName string
---@param value boolean
function m:CacheProceduralProperty(inputName, value) end

function m:ClearCache() end

function m:RebuildTextures() end

function m:RebuildTexturesImmediately() end

---@static
function m.StopRebuilds() end

---@return UnityEngine.Texture[]
function m:GetGeneratedTextures() end

---@param textureName string
---@return UnityEngine.ProceduralTexture
function m:GetGeneratedTexture(textureName) end

function m:FreezeAndReleaseSourceData() end

UnityEngine.ProceduralMaterial = m
return m
