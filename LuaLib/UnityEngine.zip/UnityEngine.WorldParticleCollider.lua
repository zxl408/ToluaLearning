---@class UnityEngine.WorldParticleCollider : UnityEngine.Component
local m = {}

UnityEngine.WorldParticleCollider = m
return m
