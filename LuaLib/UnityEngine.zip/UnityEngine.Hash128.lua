---@class UnityEngine.Hash128 : System.ValueType
---@field public isValid boolean
local m = {}

---@virtual
---@return string
function m:ToString() end

---@static
---@param hashString string
---@return UnityEngine.Hash128
function m.Parse(hashString) end

---@virtual
---@param obj any
---@return boolean
function m:Equals(obj) end

---@virtual
---@return number
function m:GetHashCode() end

---@static
---@param hash1 UnityEngine.Hash128
---@param hash2 UnityEngine.Hash128
---@return boolean
function m.op_Equality(hash1, hash2) end

---@static
---@param hash1 UnityEngine.Hash128
---@param hash2 UnityEngine.Hash128
---@return boolean
function m.op_Inequality(hash1, hash2) end

UnityEngine.Hash128 = m
return m
