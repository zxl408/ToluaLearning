---@class UnityEngine.WaitUntil : UnityEngine.CustomYieldInstruction
---@field public keepWaiting boolean
local m = {}

UnityEngine.WaitUntil = m
return m
