---@class UnityEngine.CapsuleCollider2D : UnityEngine.Collider2D
---@field public size UnityEngine.Vector2
---@field public direction UnityEngine.CapsuleDirection2D
local m = {}

UnityEngine.CapsuleCollider2D = m
return m
