---@class UnityEngine.ParticleSystemAnimationType : System.Enum
---@field public WholeSheet UnityEngine.ParticleSystemAnimationType @static
---@field public SingleRow UnityEngine.ParticleSystemAnimationType @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemAnimationType = m
return m
