---@class UnityEngine.AccelerationEvent : System.ValueType
---@field public acceleration UnityEngine.Vector3
---@field public deltaTime number
local m = {}

UnityEngine.AccelerationEvent = m
return m
