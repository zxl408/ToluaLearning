---@class UnityEngine.NetworkLogLevel : System.Enum
---@field public Off UnityEngine.NetworkLogLevel @static
---@field public Informational UnityEngine.NetworkLogLevel @static
---@field public Full UnityEngine.NetworkLogLevel @static
---@field public value__ number
local m = {}

UnityEngine.NetworkLogLevel = m
return m
