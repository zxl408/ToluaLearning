---@class UnityEngine.AudioLowPassFilter : UnityEngine.Behaviour
---@field public lowpassResonaceQ number
---@field public cutoffFrequency number
---@field public customCutoffCurve UnityEngine.AnimationCurve
---@field public lowpassResonanceQ number
local m = {}

UnityEngine.AudioLowPassFilter = m
return m
