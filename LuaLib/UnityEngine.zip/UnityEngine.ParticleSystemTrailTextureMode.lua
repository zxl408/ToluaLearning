---@class UnityEngine.ParticleSystemTrailTextureMode : System.Enum
---@field public Stretch UnityEngine.ParticleSystemTrailTextureMode @static
---@field public Tile UnityEngine.ParticleSystemTrailTextureMode @static
---@field public DistributePerSegment UnityEngine.ParticleSystemTrailTextureMode @static
---@field public RepeatPerSegment UnityEngine.ParticleSystemTrailTextureMode @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemTrailTextureMode = m
return m
