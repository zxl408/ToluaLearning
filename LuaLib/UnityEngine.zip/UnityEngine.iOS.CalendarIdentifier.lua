---@class UnityEngine.iOS.CalendarIdentifier : System.Enum
---@field public GregorianCalendar UnityEngine.iOS.CalendarIdentifier @static
---@field public BuddhistCalendar UnityEngine.iOS.CalendarIdentifier @static
---@field public ChineseCalendar UnityEngine.iOS.CalendarIdentifier @static
---@field public HebrewCalendar UnityEngine.iOS.CalendarIdentifier @static
---@field public IslamicCalendar UnityEngine.iOS.CalendarIdentifier @static
---@field public IslamicCivilCalendar UnityEngine.iOS.CalendarIdentifier @static
---@field public JapaneseCalendar UnityEngine.iOS.CalendarIdentifier @static
---@field public RepublicOfChinaCalendar UnityEngine.iOS.CalendarIdentifier @static
---@field public PersianCalendar UnityEngine.iOS.CalendarIdentifier @static
---@field public IndianCalendar UnityEngine.iOS.CalendarIdentifier @static
---@field public ISO8601Calendar UnityEngine.iOS.CalendarIdentifier @static
---@field public value__ number
local m = {}

UnityEngine.iOS.CalendarIdentifier = m
return m
