---@class UnityEngine.Mesh.InternalShaderChannel : System.Enum
---@field public Vertex UnityEngine.Mesh.InternalShaderChannel @static
---@field public Normal UnityEngine.Mesh.InternalShaderChannel @static
---@field public Color UnityEngine.Mesh.InternalShaderChannel @static
---@field public TexCoord0 UnityEngine.Mesh.InternalShaderChannel @static
---@field public TexCoord1 UnityEngine.Mesh.InternalShaderChannel @static
---@field public TexCoord2 UnityEngine.Mesh.InternalShaderChannel @static
---@field public TexCoord3 UnityEngine.Mesh.InternalShaderChannel @static
---@field public Tangent UnityEngine.Mesh.InternalShaderChannel @static
---@field public value__ number
local m = {}

UnityEngine.Mesh.InternalShaderChannel = m
return m
