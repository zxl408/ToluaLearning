---@class UnityEngine.ProceduralCacheSize : System.Enum
---@field public Tiny UnityEngine.ProceduralCacheSize @static
---@field public Medium UnityEngine.ProceduralCacheSize @static
---@field public Heavy UnityEngine.ProceduralCacheSize @static
---@field public NoLimit UnityEngine.ProceduralCacheSize @static
---@field public None UnityEngine.ProceduralCacheSize @static
---@field public value__ number
local m = {}

UnityEngine.ProceduralCacheSize = m
return m
