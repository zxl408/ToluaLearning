---@class UnityEngine.ContactPoint2D : System.ValueType
---@field public point UnityEngine.Vector2
---@field public normal UnityEngine.Vector2
---@field public separation number
---@field public normalImpulse number
---@field public tangentImpulse number
---@field public relativeVelocity UnityEngine.Vector2
---@field public collider UnityEngine.Collider2D
---@field public otherCollider UnityEngine.Collider2D
---@field public rigidbody UnityEngine.Rigidbody2D
---@field public otherRigidbody UnityEngine.Rigidbody2D
---@field public enabled boolean
local m = {}

UnityEngine.ContactPoint2D = m
return m
