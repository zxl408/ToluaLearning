---@class UnityEngine.WWWForm : System.Object
---@field public headers System.Collections.Generic.Dictionary_2_System_String_System_String_
---@field public data string
local m = {}

---@overload fun(fieldName:string, value:string, e:System.Text.Encoding)
---@overload fun(fieldName:string, i:number)
---@param fieldName string
---@param value string
function m:AddField(fieldName, value) end

---@overload fun(fieldName:string, contents:string)
---@overload fun(fieldName:string, contents:string, fileName:string, mimeType:string)
---@param fieldName string
---@param contents string
---@param fileName string
function m:AddBinaryData(fieldName, contents, fileName) end

UnityEngine.WWWForm = m
return m
