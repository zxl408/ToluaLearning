---@class UnityEngine.ProceduralTexture : UnityEngine.Texture
---@field public hasAlpha boolean
---@field public format UnityEngine.TextureFormat
local m = {}

---@return UnityEngine.ProceduralOutputType
function m:GetProceduralOutputType() end

---@param x number
---@param y number
---@param blockWidth number
---@param blockHeight number
---@return UnityEngine.Color32[]
function m:GetPixels32(x, y, blockWidth, blockHeight) end

UnityEngine.ProceduralTexture = m
return m
