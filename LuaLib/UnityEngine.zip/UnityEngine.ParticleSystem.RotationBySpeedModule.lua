---@class UnityEngine.ParticleSystem.RotationBySpeedModule : System.ValueType
---@field public enabled boolean
---@field public x UnityEngine.ParticleSystem.MinMaxCurve
---@field public xMultiplier number
---@field public y UnityEngine.ParticleSystem.MinMaxCurve
---@field public yMultiplier number
---@field public z UnityEngine.ParticleSystem.MinMaxCurve
---@field public zMultiplier number
---@field public separateAxes boolean
---@field public range UnityEngine.Vector2
local m = {}

UnityEngine.ParticleSystem.RotationBySpeedModule = m
return m
