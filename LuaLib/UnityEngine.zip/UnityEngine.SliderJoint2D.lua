---@class UnityEngine.SliderJoint2D : UnityEngine.AnchoredJoint2D
---@field public autoConfigureAngle boolean
---@field public angle number
---@field public useMotor boolean
---@field public useLimits boolean
---@field public motor UnityEngine.JointMotor2D
---@field public limits UnityEngine.JointTranslationLimits2D
---@field public limitState UnityEngine.JointLimitState2D
---@field public referenceAngle number
---@field public jointTranslation number
---@field public jointSpeed number
local m = {}

---@param timeStep number
---@return number
function m:GetMotorForce(timeStep) end

UnityEngine.SliderJoint2D = m
return m
