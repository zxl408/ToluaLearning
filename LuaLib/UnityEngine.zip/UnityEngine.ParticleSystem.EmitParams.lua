---@class UnityEngine.ParticleSystem.EmitParams : System.ValueType
---@field public position UnityEngine.Vector3
---@field public applyShapeToPosition boolean
---@field public velocity UnityEngine.Vector3
---@field public startLifetime number
---@field public startSize number
---@field public startSize3D UnityEngine.Vector3
---@field public axisOfRotation UnityEngine.Vector3
---@field public rotation number
---@field public rotation3D UnityEngine.Vector3
---@field public angularVelocity number
---@field public angularVelocity3D UnityEngine.Vector3
---@field public startColor UnityEngine.Color32
---@field public randomSeed number
local m = {}

function m:ResetPosition() end

function m:ResetVelocity() end

function m:ResetAxisOfRotation() end

function m:ResetRotation() end

function m:ResetAngularVelocity() end

function m:ResetStartSize() end

function m:ResetStartColor() end

function m:ResetRandomSeed() end

function m:ResetStartLifetime() end

UnityEngine.ParticleSystem.EmitParams = m
return m
