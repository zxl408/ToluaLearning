---@class UnityEngine.ProceduralPropertyType : System.Enum
---@field public Boolean UnityEngine.ProceduralPropertyType @static
---@field public Float UnityEngine.ProceduralPropertyType @static
---@field public Vector2 UnityEngine.ProceduralPropertyType @static
---@field public Vector3 UnityEngine.ProceduralPropertyType @static
---@field public Vector4 UnityEngine.ProceduralPropertyType @static
---@field public Color3 UnityEngine.ProceduralPropertyType @static
---@field public Color4 UnityEngine.ProceduralPropertyType @static
---@field public Enum UnityEngine.ProceduralPropertyType @static
---@field public Texture UnityEngine.ProceduralPropertyType @static
---@field public value__ number
local m = {}

UnityEngine.ProceduralPropertyType = m
return m
