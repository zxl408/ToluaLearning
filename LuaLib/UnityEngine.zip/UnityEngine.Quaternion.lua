---@class UnityEngine.Quaternion : System.ValueType
---@field public kEpsilon number @static
---@field public identity UnityEngine.Quaternion @static
---@field public x number
---@field public y number
---@field public z number
---@field public w number
---@field public eulerAngles UnityEngine.Vector3
---@field public Item number
local m = {}

---@static
---@param angle number
---@param axis UnityEngine.Vector3
---@return UnityEngine.Quaternion
function m.AngleAxis(angle, axis) end

---@return System.Single, UnityEngine.Vector3
function m:ToAngleAxis() end

---@static
---@param fromDirection UnityEngine.Vector3
---@param toDirection UnityEngine.Vector3
---@return UnityEngine.Quaternion
function m.FromToRotation(fromDirection, toDirection) end

---@param fromDirection UnityEngine.Vector3
---@param toDirection UnityEngine.Vector3
function m:SetFromToRotation(fromDirection, toDirection) end

---@overload fun(forward:UnityEngine.Vector3): @static
---@static
---@param forward UnityEngine.Vector3
---@param upwards UnityEngine.Vector3
---@return UnityEngine.Quaternion
function m.LookRotation(forward, upwards) end

---@static
---@param a UnityEngine.Quaternion
---@param b UnityEngine.Quaternion
---@param t number
---@return UnityEngine.Quaternion
function m.Slerp(a, b, t) end

---@static
---@param a UnityEngine.Quaternion
---@param b UnityEngine.Quaternion
---@param t number
---@return UnityEngine.Quaternion
function m.SlerpUnclamped(a, b, t) end

---@static
---@param a UnityEngine.Quaternion
---@param b UnityEngine.Quaternion
---@param t number
---@return UnityEngine.Quaternion
function m.Lerp(a, b, t) end

---@static
---@param a UnityEngine.Quaternion
---@param b UnityEngine.Quaternion
---@param t number
---@return UnityEngine.Quaternion
function m.LerpUnclamped(a, b, t) end

---@static
---@param from UnityEngine.Quaternion
---@param to UnityEngine.Quaternion
---@param maxDegreesDelta number
---@return UnityEngine.Quaternion
function m.RotateTowards(from, to, maxDegreesDelta) end

---@static
---@param rotation UnityEngine.Quaternion
---@return UnityEngine.Quaternion
function m.Inverse(rotation) end

---@overload fun(euler:UnityEngine.Vector3): @static
---@static
---@param x number
---@param y number
---@param z number
---@return UnityEngine.Quaternion
function m.Euler(x, y, z) end

---@overload fun(euler:UnityEngine.Vector3): @static
---@static
---@param x number
---@param y number
---@param z number
---@return UnityEngine.Quaternion
function m.EulerRotation(x, y, z) end

---@overload fun(euler:UnityEngine.Vector3)
---@param x number
---@param y number
---@param z number
function m:SetEulerRotation(x, y, z) end

---@return UnityEngine.Vector3
function m:ToEuler() end

---@overload fun(euler:UnityEngine.Vector3): @static
---@static
---@param x number
---@param y number
---@param z number
---@return UnityEngine.Quaternion
function m.EulerAngles(x, y, z) end

---@return UnityEngine.Vector3, System.Single
function m:ToAxisAngle() end

---@overload fun(euler:UnityEngine.Vector3)
---@param x number
---@param y number
---@param z number
function m:SetEulerAngles(x, y, z) end

---@overload fun():
---@static
---@param rotation UnityEngine.Quaternion
---@return UnityEngine.Vector3
function m.ToEulerAngles(rotation) end

---@static
---@param axis UnityEngine.Vector3
---@param angle number
---@return UnityEngine.Quaternion
function m.AxisAngle(axis, angle) end

---@param axis UnityEngine.Vector3
---@param angle number
function m:SetAxisAngle(axis, angle) end

---@param new_x number
---@param new_y number
---@param new_z number
---@param new_w number
function m:Set(new_x, new_y, new_z, new_w) end

---@overload fun(rotation:UnityEngine.Quaternion, point:UnityEngine.Vector3): @static
---@static
---@param lhs UnityEngine.Quaternion
---@param rhs UnityEngine.Quaternion
---@return UnityEngine.Quaternion
function m.op_Multiply(lhs, rhs) end

---@static
---@param lhs UnityEngine.Quaternion
---@param rhs UnityEngine.Quaternion
---@return boolean
function m.op_Equality(lhs, rhs) end

---@static
---@param lhs UnityEngine.Quaternion
---@param rhs UnityEngine.Quaternion
---@return boolean
function m.op_Inequality(lhs, rhs) end

---@static
---@param a UnityEngine.Quaternion
---@param b UnityEngine.Quaternion
---@return number
function m.Dot(a, b) end

---@overload fun(view:UnityEngine.Vector3, up:UnityEngine.Vector3)
---@param view UnityEngine.Vector3
function m:SetLookRotation(view) end

---@static
---@param a UnityEngine.Quaternion
---@param b UnityEngine.Quaternion
---@return number
function m.Angle(a, b) end

---@virtual
---@return number
function m:GetHashCode() end

---@virtual
---@param other any
---@return boolean
function m:Equals(other) end

---@overload fun(format:string):
---@virtual
---@return string
function m:ToString() end

UnityEngine.Quaternion = m
return m
