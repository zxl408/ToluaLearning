---@class UnityEngine.ParticleSystemCollisionType : System.Enum
---@field public Planes UnityEngine.ParticleSystemCollisionType @static
---@field public World UnityEngine.ParticleSystemCollisionType @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemCollisionType = m
return m
