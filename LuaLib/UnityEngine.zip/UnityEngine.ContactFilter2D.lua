---@class UnityEngine.ContactFilter2D : System.ValueType
---@field public NormalAngleUpperLimit number @static
---@field public useTriggers boolean
---@field public useLayerMask boolean
---@field public useDepth boolean
---@field public useOutsideDepth boolean
---@field public useNormalAngle boolean
---@field public useOutsideNormalAngle boolean
---@field public layerMask UnityEngine.LayerMask
---@field public minDepth number
---@field public maxDepth number
---@field public minNormalAngle number
---@field public maxNormalAngle number
---@field public isFiltering boolean
local m = {}

---@return UnityEngine.ContactFilter2D
function m:NoFilter() end

function m:ClearLayerMask() end

---@param layerMask UnityEngine.LayerMask
function m:SetLayerMask(layerMask) end

function m:ClearDepth() end

---@param minDepth number
---@param maxDepth number
function m:SetDepth(minDepth, maxDepth) end

function m:ClearNormalAngle() end

---@param minNormalAngle number
---@param maxNormalAngle number
function m:SetNormalAngle(minNormalAngle, maxNormalAngle) end

---@param collider UnityEngine.Collider2D
---@return boolean
function m:IsFilteringTrigger(collider) end

---@param obj UnityEngine.GameObject
---@return boolean
function m:IsFilteringLayerMask(obj) end

---@param obj UnityEngine.GameObject
---@return boolean
function m:IsFilteringDepth(obj) end

---@overload fun(angle:number):
---@param normal UnityEngine.Vector2
---@return boolean
function m:IsFilteringNormalAngle(normal) end

UnityEngine.ContactFilter2D = m
return m
