---@class UnityEngine.ParticleSystemExtensionsImpl : System.Object
local m = {}

UnityEngine.ParticleSystemExtensionsImpl = m
return m
