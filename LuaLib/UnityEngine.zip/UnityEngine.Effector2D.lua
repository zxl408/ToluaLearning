---@class UnityEngine.Effector2D : UnityEngine.Behaviour
---@field public useColliderMask boolean
---@field public colliderMask number
local m = {}

UnityEngine.Effector2D = m
return m
