---@class UnityEngine.ParticleSystemShapeMultiModeValue : System.Enum
---@field public Random UnityEngine.ParticleSystemShapeMultiModeValue @static
---@field public Loop UnityEngine.ParticleSystemShapeMultiModeValue @static
---@field public PingPong UnityEngine.ParticleSystemShapeMultiModeValue @static
---@field public BurstSpread UnityEngine.ParticleSystemShapeMultiModeValue @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemShapeMultiModeValue = m
return m
