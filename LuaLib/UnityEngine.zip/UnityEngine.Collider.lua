---@class UnityEngine.Collider : UnityEngine.Component
---@field public enabled boolean
---@field public attachedRigidbody UnityEngine.Rigidbody
---@field public isTrigger boolean
---@field public contactOffset number
---@field public material UnityEngine.PhysicMaterial
---@field public sharedMaterial UnityEngine.PhysicMaterial
---@field public bounds UnityEngine.Bounds
local m = {}

---@param position UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:ClosestPointOnBounds(position) end

---@param position UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:ClosestPoint(position) end

---@param ray UnityEngine.Ray
---@param maxDistance number
---@return boolean, UnityEngine.RaycastHit
function m:Raycast(ray, maxDistance) end

UnityEngine.Collider = m
return m
