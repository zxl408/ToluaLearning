---@class UnityEngine.CombineInstanceHelper : System.ValueType
local m = {}

UnityEngine.CombineInstanceHelper = m
return m
