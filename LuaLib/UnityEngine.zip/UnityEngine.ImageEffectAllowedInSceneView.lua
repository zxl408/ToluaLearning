---@class UnityEngine.ImageEffectAllowedInSceneView : System.Attribute
local m = {}

UnityEngine.ImageEffectAllowedInSceneView = m
return m
