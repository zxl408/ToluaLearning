---@class UnityEngine.YieldInstruction : System.Object
local m = {}

UnityEngine.YieldInstruction = m
return m
