---@class UnityEngine.JointProjectionMode : System.Enum
---@field public None UnityEngine.JointProjectionMode @static
---@field public PositionAndRotation UnityEngine.JointProjectionMode @static
---@field public PositionOnly UnityEngine.JointProjectionMode @static
---@field public value__ number
local m = {}

UnityEngine.JointProjectionMode = m
return m
