---@class UnityEngine.AudioSettings.AudioConfigurationChangeHandler : System.MulticastDelegate
local m = {}

---@virtual
---@param deviceWasChanged boolean
function m:Invoke(deviceWasChanged) end

---@virtual
---@param deviceWasChanged boolean
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(deviceWasChanged, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

UnityEngine.AudioSettings.AudioConfigurationChangeHandler = m
return m
