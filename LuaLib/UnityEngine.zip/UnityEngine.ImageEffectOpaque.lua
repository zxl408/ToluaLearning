---@class UnityEngine.ImageEffectOpaque : System.Attribute
local m = {}

UnityEngine.ImageEffectOpaque = m
return m
