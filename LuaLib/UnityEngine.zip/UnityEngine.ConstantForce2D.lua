---@class UnityEngine.ConstantForce2D : UnityEngine.PhysicsUpdateBehaviour2D
---@field public force UnityEngine.Vector2
---@field public relativeForce UnityEngine.Vector2
---@field public torque number
local m = {}

UnityEngine.ConstantForce2D = m
return m
