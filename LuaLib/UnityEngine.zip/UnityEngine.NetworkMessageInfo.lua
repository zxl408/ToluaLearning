---@class UnityEngine.NetworkMessageInfo : System.ValueType
---@field public timestamp number
---@field public sender UnityEngine.NetworkPlayer
---@field public networkView UnityEngine.NetworkView
local m = {}

UnityEngine.NetworkMessageInfo = m
return m
