---@class UnityEngine.RotationDriveMode : System.Enum
---@field public XYAndZ UnityEngine.RotationDriveMode @static
---@field public Slerp UnityEngine.RotationDriveMode @static
---@field public value__ number
local m = {}

UnityEngine.RotationDriveMode = m
return m
