---@class UnityEngine.CapsuleDirection2D : System.Enum
---@field public Vertical UnityEngine.CapsuleDirection2D @static
---@field public Horizontal UnityEngine.CapsuleDirection2D @static
---@field public value__ number
local m = {}

UnityEngine.CapsuleDirection2D = m
return m
