---@class UnityEngine.HingeJoint2D : UnityEngine.AnchoredJoint2D
---@field public useMotor boolean
---@field public useLimits boolean
---@field public motor UnityEngine.JointMotor2D
---@field public limits UnityEngine.JointAngleLimits2D
---@field public limitState UnityEngine.JointLimitState2D
---@field public referenceAngle number
---@field public jointAngle number
---@field public jointSpeed number
local m = {}

---@param timeStep number
---@return number
function m:GetMotorTorque(timeStep) end

UnityEngine.HingeJoint2D = m
return m
