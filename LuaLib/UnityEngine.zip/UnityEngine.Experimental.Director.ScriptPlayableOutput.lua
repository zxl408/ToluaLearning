---@class UnityEngine.Experimental.Director.ScriptPlayableOutput : System.ValueType
---@field public Null UnityEngine.Experimental.Director.ScriptPlayableOutput @static
---@field public userData UnityEngine.Object
---@field public sourcePlayable UnityEngine.Experimental.Director.PlayableHandle
local m = {}

---@return boolean
function m:IsValid() end

UnityEngine.Experimental.Director.ScriptPlayableOutput = m
return m
