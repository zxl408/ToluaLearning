---@class UnityEngine.SpriteDrawMode : System.Enum
---@field public Simple UnityEngine.SpriteDrawMode @static
---@field public Sliced UnityEngine.SpriteDrawMode @static
---@field public Tiled UnityEngine.SpriteDrawMode @static
---@field public value__ number
local m = {}

UnityEngine.SpriteDrawMode = m
return m
