---@class UnityEngine.SoftJointLimitSpring : System.ValueType
---@field public spring number
---@field public damper number
local m = {}

UnityEngine.SoftJointLimitSpring = m
return m
