---@class UnityEngine.ParticleSystemShapeType : System.Enum
---@field public Sphere UnityEngine.ParticleSystemShapeType @static
---@field public SphereShell UnityEngine.ParticleSystemShapeType @static
---@field public Hemisphere UnityEngine.ParticleSystemShapeType @static
---@field public HemisphereShell UnityEngine.ParticleSystemShapeType @static
---@field public Cone UnityEngine.ParticleSystemShapeType @static
---@field public Box UnityEngine.ParticleSystemShapeType @static
---@field public Mesh UnityEngine.ParticleSystemShapeType @static
---@field public ConeShell UnityEngine.ParticleSystemShapeType @static
---@field public ConeVolume UnityEngine.ParticleSystemShapeType @static
---@field public ConeVolumeShell UnityEngine.ParticleSystemShapeType @static
---@field public Circle UnityEngine.ParticleSystemShapeType @static
---@field public CircleEdge UnityEngine.ParticleSystemShapeType @static
---@field public SingleSidedEdge UnityEngine.ParticleSystemShapeType @static
---@field public MeshRenderer UnityEngine.ParticleSystemShapeType @static
---@field public SkinnedMeshRenderer UnityEngine.ParticleSystemShapeType @static
---@field public BoxShell UnityEngine.ParticleSystemShapeType @static
---@field public BoxEdge UnityEngine.ParticleSystemShapeType @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemShapeType = m
return m
