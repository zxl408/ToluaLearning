---@class UnityEngine.WindZone : UnityEngine.Component
---@field public mode UnityEngine.WindZoneMode
---@field public radius number
---@field public windMain number
---@field public windTurbulence number
---@field public windPulseMagnitude number
---@field public windPulseFrequency number
local m = {}

UnityEngine.WindZone = m
return m
