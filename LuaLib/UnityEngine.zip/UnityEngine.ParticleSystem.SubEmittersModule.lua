---@class UnityEngine.ParticleSystem.SubEmittersModule : System.ValueType
---@field public enabled boolean
---@field public subEmittersCount number
---@field public birth0 UnityEngine.ParticleSystem
---@field public birth1 UnityEngine.ParticleSystem
---@field public collision0 UnityEngine.ParticleSystem
---@field public collision1 UnityEngine.ParticleSystem
---@field public death0 UnityEngine.ParticleSystem
---@field public death1 UnityEngine.ParticleSystem
local m = {}

---@param subEmitter UnityEngine.ParticleSystem
---@param type UnityEngine.ParticleSystemSubEmitterType
---@param properties UnityEngine.ParticleSystemSubEmitterProperties
function m:AddSubEmitter(subEmitter, type, properties) end

---@param index number
function m:RemoveSubEmitter(index) end

---@param index number
---@param subEmitter UnityEngine.ParticleSystem
function m:SetSubEmitterSystem(index, subEmitter) end

---@param index number
---@param type UnityEngine.ParticleSystemSubEmitterType
function m:SetSubEmitterType(index, type) end

---@param index number
---@param properties UnityEngine.ParticleSystemSubEmitterProperties
function m:SetSubEmitterProperties(index, properties) end

---@param index number
---@return UnityEngine.ParticleSystem
function m:GetSubEmitterSystem(index) end

---@param index number
---@return UnityEngine.ParticleSystemSubEmitterType
function m:GetSubEmitterType(index) end

---@param index number
---@return UnityEngine.ParticleSystemSubEmitterProperties
function m:GetSubEmitterProperties(index) end

UnityEngine.ParticleSystem.SubEmittersModule = m
return m
