---@class UnityEngine.SpriteTileMode : System.Enum
---@field public Continuous UnityEngine.SpriteTileMode @static
---@field public Adaptive UnityEngine.SpriteTileMode @static
---@field public value__ number
local m = {}

UnityEngine.SpriteTileMode = m
return m
